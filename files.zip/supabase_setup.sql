-- Run this in your Supabase SQL Editor (Step 3 of the guide)
-- It creates one table that stores all your CRM data

CREATE TABLE IF NOT EXISTS crm_store (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Allow your app to read and write (using the anon key)
ALTER TABLE crm_store ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all for anon" ON crm_store
  FOR ALL USING (true) WITH CHECK (true);
