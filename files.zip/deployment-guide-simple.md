# Lead Manager CRM — Simple Deployment Guide
### No Terminal. No coding. Just clicking.

**Time needed:** About 45 minutes
**What you will create:** A private URL your whole team can bookmark

---

## Overview

You will use two free services:

- **Supabase** — stores your data online (like a database in the cloud)
- **Replit** — hosts the app at a web address your team can visit

Both are free. Both are entirely browser-based.

---

## PART 1 — Set up your database (Supabase)

### Step 1: Create a Supabase account

1. Go to: https://supabase.com
2. Click "Start your project"
3. Sign up with Google or email
4. Once signed in, click "New project"

### Step 2: Create your project

Fill in the form:
- Name: lead-manager
- Database Password: make one up and write it down
- Region: West EU (Ireland) or closest to your team

Click "Create new project" and wait 2 minutes for setup.

### Step 3: Create the data table

1. In the left sidebar, click "SQL Editor"
2. Click "New query"
3. Delete anything in the text box, then paste this:

CREATE TABLE IF NOT EXISTS crm_store (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE crm_store ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow all for anon" ON crm_store
  FOR ALL USING (true) WITH CHECK (true);

4. Click the green "Run" button
5. You should see: "Success. No rows returned"

### Step 4: Copy your two credentials

1. Click "Settings" (gear icon, bottom of left sidebar)
2. Click "API"
3. Copy and save these two values somewhere (e.g. Notepad):
   - Project URL — looks like: https://abcde.supabase.co
   - anon / public key — a very long string starting with eyJ...

---

## PART 2 — Host the app (Replit)

### Step 1: Create a Replit account

1. Go to: https://replit.com
2. Click "Sign up" and create a free account

### Step 2: Create a new React project

1. Click the blue "+ Create Repl" button
2. Search for the "React" template and select it
3. Name it: lead-manager-crm
4. Click "Create Repl"

Wait 30 seconds for it to load.

### Step 3: Upload your files

1. Unzip the file "lead-manager-replit.zip" on your computer
2. You will see a folder called "replit-project" with files inside
3. In Replit, look at the left file panel
4. Delete the default files Replit created (right-click each one, click Delete):
   - Delete the "src" folder
   - Delete "package.json"
   - Delete "vite.config.js" if it exists
5. Upload your files from the unzipped folder:
   - Click the three dots (...) at the top of the file panel
   - Click "Upload file" or drag and drop files from your computer
   - Create a "src" folder and upload App.jsx and main.jsx into it
   - Create a "public" folder and upload index.html into it
   - Upload package.json, vite.config.js, .replit, and replit.nix to the main folder

### Step 4: Add your credentials (no code editing needed)

1. In the left sidebar, click the lock icon (Secrets)
2. Click "New secret" and add:
   - Key: VITE_SUPABASE_URL
   - Value: (paste your Supabase Project URL from Part 1)
   - Click "Add secret"
3. Click "New secret" again and add:
   - Key: VITE_SUPABASE_ANON_KEY
   - Value: (paste your anon key from Part 1)
   - Click "Add secret"

### Step 5: Run the app

1. Click the "Shell" tab at the bottom of Replit
2. Type: npm install
3. Press Enter and wait 30-60 seconds
4. Then type: npm run dev
5. Press Enter — the preview on the right will show your CRM

---

## PART 3 — Share with your team

Copy the URL from the preview panel and send it to your team.

Default login credentials (all use password: Lead2024!)

| Username          | Person               |
|-------------------|----------------------|
| paul.janssen      | Paul Janssen         |
| daniel.sanz       | Daniel Sanz          |
| chinedu.onuegbu   | Chinedu Onuegbu      |
| ahmed.abdou       | Ahmed Abdou          |
| zbigniew.myslinksi| Zbigniew Myslinksi   |
| internal.sales    | Internal Sales / CS  |
| user7 to user12   | (set up in Settings) |

Log in as paul.janssen first — that account is the admin. Go to Settings to rename
the user7-user12 accounts and update passwords for your team.

---

## If something goes wrong

Just come back here and paste the error message you see — I will tell you exactly what to do next.

